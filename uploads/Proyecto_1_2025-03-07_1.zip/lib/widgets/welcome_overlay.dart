import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:parking_localization/providers/user_provider.dart';

class WelcomeOverlay extends StatefulWidget {
  const WelcomeOverlay({super.key});

  @override
  State<WelcomeOverlay> createState() => _WelcomeOverlayState();
}

class _WelcomeOverlayState extends State<WelcomeOverlay> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _profileAliasController = TextEditingController();
  final TextEditingController _vehicleNameController = TextEditingController();
  String _selectedCountry = 'España';

  final List<String> _countries = [
    'España',
    'México',
    'Argentina',
    'Colombia',
    'Chile',
    'Perú',
    'Ecuador',
    'Venezuela',
    'Estados Unidos',
    'Canadá',
    'Brasil',
    'Francia',
    'Alemania',
    'Italia',
    'Reino Unido',
    'Portugal',
    'Otro'
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black.withOpacity(0.7),
      width: double.infinity,
      height: double.infinity,
      child: Center(
        child: Card(
          margin: const EdgeInsets.all(16),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    '¡Bienvenido a Parking Localization!',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 20),
                  
                  // Country selection
                  DropdownButtonFormField<String>(
                    decoration: const InputDecoration(
                      labelText: 'País',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.public),
                    ),
                    value: _selectedCountry,
                    items: _countries.map((String country) {
                      return DropdownMenuItem<String>(
                        value: country,
                        child: Text(country),
                      );
                    }).toList(),
                    onChanged: (String? newValue) {
                      if (newValue != null) {
                        setState(() {
                          _selectedCountry = newValue;
                        });
                      }
                    },
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Por favor selecciona un país';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  
                  // Profile alias
                  TextFormField(
                    controller: _profileAliasController,
                    decoration: const InputDecoration(
                      labelText: 'Alias del perfil',
                      hintText: 'Ej: Juan Pérez',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.person),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Por favor ingresa un alias';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  
                  // Vehicle name
                  TextFormField(
                    controller: _vehicleNameController,
                    decoration: const InputDecoration(
                      labelText: 'Nombre del vehículo',
                      hintText: 'Ej: Camioneta Roja Ford',
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.directions_car),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Por favor ingresa el nombre de tu vehículo';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 24),
                  
                  // Save button
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _saveProfile,
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      child: const Text(
                        'Guardar Perfil',
                        style: TextStyle(fontSize: 16),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _saveProfile() {
    if (_formKey.currentState!.validate()) {
      final userProvider = Provider.of<UserProvider>(context, listen: false);
      
      userProvider.saveUserProfile(
        profileAlias: _profileAliasController.text,
        vehicleName: _vehicleNameController.text,
        country: _selectedCountry,
      );
    }
  }
}

