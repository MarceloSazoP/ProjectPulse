import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserProvider extends ChangeNotifier {
  String _profileAlias = '';
  String _vehicleName = '';
  String _country = '';
  bool _isProfileComplete = false;

  String get profileAlias => _profileAlias;
  String get vehicleName => _vehicleName;
  String get country => _country;
  bool get isProfileComplete => _isProfileComplete;

  UserProvider() {
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final prefs = await SharedPreferences.getInstance();
    _profileAlias = prefs.getString('profileAlias') ?? '';
    _vehicleName = prefs.getString('vehicleName') ?? '';
    _country = prefs.getString('country') ?? '';
    _isProfileComplete = prefs.getBool('isProfileComplete') ?? false;
    notifyListeners();
  }

  Future<void> saveUserProfile({
    required String profileAlias,
    required String vehicleName,
    required String country,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    
    await prefs.setString('profileAlias', profileAlias);
    await prefs.setString('vehicleName', vehicleName);
    await prefs.setString('country', country);
    await prefs.setBool('isProfileComplete', true);
    
    _profileAlias = profileAlias;
    _vehicleName = vehicleName;
    _country = country;
    _isProfileComplete = true;
    
    notifyListeners();
  }
}

