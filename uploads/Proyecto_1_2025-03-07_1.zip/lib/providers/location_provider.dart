import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LocationProvider extends ChangeNotifier {
  LatLng? _currentLocation;
  LatLng? _parkingLocation;
  bool _isLocationPermissionGranted = false;
  bool _isGpsEnabled = false;

  // Default location (Madrid, Spain) in case GPS is not available
  final LatLng _defaultLocation = const LatLng(40.416775, -3.703790);

  LatLng get currentLocation => _currentLocation ?? _defaultLocation;
  LatLng? get parkingLocation => _parkingLocation;
  bool get isLocationPermissionGranted => _isLocationPermissionGranted;
  bool get isGpsEnabled => _isGpsEnabled;

  LocationProvider() {
    _checkPermissionAndLocation();
    _loadParkingLocation();
  }

  Future<void> _loadParkingLocation() async {
    final prefs = await SharedPreferences.getInstance();
    final double? lat = prefs.getDouble('parking_lat');
    final double? lng = prefs.getDouble('parking_lng');
    
    if (lat != null && lng != null) {
      _parkingLocation = LatLng(lat, lng);
      notifyListeners();
    }
  }

  Future<void> _checkPermissionAndLocation() async {
    _isLocationPermissionGranted = await _handleLocationPermission();
    _isGpsEnabled = await _isLocationServiceEnabled();
    
    if (_isLocationPermissionGranted && _isGpsEnabled) {
      await getCurrentLocation();
    }
    
    notifyListeners();
  }

  Future<bool> _isLocationServiceEnabled() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    return serviceEnabled;
  }

  Future<bool> _handleLocationPermission() async {
    LocationPermission permission = await Geolocator.checkPermission();
    
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return false;
      }
    }
    
    if (permission == LocationPermission.deniedForever) {
      return false;
    }
    
    return true;
  }

  Future<void> getCurrentLocation() async {
    try {
      if (!await _isLocationServiceEnabled()) {
        _isGpsEnabled = false;
        notifyListeners();
        return;
      }
      
      if (!await _handleLocationPermission()) {
        _isLocationPermissionGranted = false;
        notifyListeners();
        return;
      }
      
      _isGpsEnabled = true;
      _isLocationPermissionGranted = true;
      
      Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high
      );
      
      _currentLocation = LatLng(position.latitude, position.longitude);
      notifyListeners();
    } catch (e) {
      debugPrint('Error getting location: $e');
      _currentLocation = _defaultLocation;
      notifyListeners();
    }
  }

  Future<void> saveParkingLocation(LatLng location) async {
    _parkingLocation = location;
    
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('parking_lat', location.latitude);
    await prefs.setDouble('parking_lng', location.longitude);
    
    notifyListeners();
  }
}

