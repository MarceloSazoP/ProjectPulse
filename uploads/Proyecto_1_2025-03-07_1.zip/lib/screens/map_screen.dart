import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:parking_localization/providers/location_provider.dart';
import 'package:parking_localization/providers/user_provider.dart';
import 'package:parking_localization/widgets/welcome_overlay.dart';
import 'package:url_launcher/url_launcher.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  GoogleMapController? _mapController;
  Set<Marker> _markers = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _updateMarkers();
    });
  }

  void _updateMarkers() {
    final locationProvider = Provider.of<LocationProvider>(context, listen: false);
    
    Set<Marker> markers = {};
    
    // Add current location marker (blue)
    markers.add(
      Marker(
        markerId: const MarkerId('current_location'),
        position: locationProvider.currentLocation,
        icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueAzure),
        infoWindow: const InfoWindow(title: 'Mi ubicación actual'),
      ),
    );
    
    // Add parking location marker (red) if available
    if (locationProvider.parkingLocation != null) {
      markers.add(
        Marker(
          markerId: const MarkerId('parking_location'),
          position: locationProvider.parkingLocation!,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed),
          infoWindow: const InfoWindow(title: 'Mi estacionamiento'),
        ),
      );
    }
    
    setState(() {
      _markers = markers;
    });
  }

  void _onMapCreated(GoogleMapController controller) {
    _mapController = controller;
    _updateMarkers();
  }

  Future<void> _navigateToParkingLocation() async {
    final locationProvider = Provider.of<LocationProvider>(context, listen: false);
    
    if (locationProvider.parkingLocation == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No has guardado ninguna ubicación de estacionamiento')),
      );
      return;
    }
    
    final lat = locationProvider.parkingLocation!.latitude;
    final lng = locationProvider.parkingLocation!.longitude;
    final url = 'https://www.google.com/maps/dir/?api=1&destination=$lat,$lng&travelmode=walking';
    
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No se pudo abrir Google Maps')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final locationProvider = Provider.of<LocationProvider>(context);
    final userProvider = Provider.of<UserProvider>(context);
    
    return Scaffold(
      body: Stack(
        children: [
          GoogleMap(
            onMapCreated: _onMapCreated,
            initialCameraPosition: CameraPosition(
              target: locationProvider.currentLocation,
              zoom: 15,
            ),
            myLocationEnabled: locationProvider.isLocationPermissionGranted,
            myLocationButtonEnabled: false,
            markers: _markers,
            onLongPress: (LatLng position) {
              locationProvider.saveParkingLocation(position);
              _updateMarkers();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Ubicación de estacionamiento guardada')),
              );
            },
          ),
          
          // Show welcome overlay if profile is not complete
          if (!userProvider.isProfileComplete)
            const WelcomeOverlay(),
            
          // GPS warning message
          if (!locationProvider.isGpsEnabled)
            Positioned(
              top: MediaQuery.of(context).padding.top + 10,
              left: 10,
              right: 10,
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.8),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  'GPS desactivado. Por favor, activa tu ubicación para una mejor experiencia.',
                  style: TextStyle(color: Colors.white),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
            
          // Permission warning message
          if (!locationProvider.isLocationPermissionGranted)
            Positioned(
              top: locationProvider.isGpsEnabled 
                  ? MediaQuery.of(context).padding.top + 10 
                  : MediaQuery.of(context).padding.top + 60,
              left: 10,
              right: 10,
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.orange.withOpacity(0.8),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  'Permiso de ubicación denegado. Por favor, concede permisos de ubicación en la configuración.',
                  style: TextStyle(color: Colors.white),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
        ],
      ),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton(
            heroTag: 'refresh_location',
            onPressed: () async {
              await locationProvider.getCurrentLocation();
              _updateMarkers();
              if (_mapController != null && locationProvider.currentLocation != null) {
                _mapController!.animateCamera(
                  CameraUpdate.newLatLng(locationProvider.currentLocation),
                );
              }
            },
            child: const Icon(Icons.my_location),
          ),
          const SizedBox(height: 16),
          FloatingActionButton(
            heroTag: 'navigate',
            onPressed: _navigateToParkingLocation,
            backgroundColor: Colors.green,
            child: const Icon(Icons.directions),
          ),
        ],
      ),
    );
  }
}

